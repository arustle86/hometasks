<?php
   class Redux_Customizer_Control_slider extends Redux_Customizer_Control {
     public $type = "redux-slider";
   }