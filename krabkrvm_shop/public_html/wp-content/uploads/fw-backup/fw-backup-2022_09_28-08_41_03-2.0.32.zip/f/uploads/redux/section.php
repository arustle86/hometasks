<?php
   class Redux_Customizer_Control_section extends Redux_Customizer_Control {
     public $type = "redux-section";
   }